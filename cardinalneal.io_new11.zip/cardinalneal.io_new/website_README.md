# CardinalNeal website own README



1. write `about` 在 `_pages/about.md`
2. 换封面图在 `assert/img`的prof_pic.jpg
3. `_config.yaml`
4. `_pages/profiles.md` 里的 地址是在 指向 `people` 版块的